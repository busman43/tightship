<?php
/**
 * Template Name: TightShip Workspace
 */

declare(strict_types=1);

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

get_header();

while ( have_posts() ) :
    the_post();
    ?>
    <article class="tw-card">
        <?php the_title( '<h1 style="margin:0 0 10px;font-weight:900;letter-spacing:-0.02em;">', '</h1>' ); ?>

        <div class="entry-content">
            <?php
            if ( shortcode_exists( 'tightship_dashboard' ) && shortcode_exists( 'tightship_login' ) ) {
                echo do_shortcode( is_user_logged_in() ? '[tightship_dashboard]' : '[tightship_login]' );
            } else {
                echo '<p>' . esc_html__( 'TightShip Engine is not active. Activate the plugin to render the workspace.', 'tightship-workspace' ) . '</p>';
            }
            ?>
        </div>
    </article>
    <?php
endwhile;

get_footer();
