<?php
declare(strict_types=1);

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

?><!doctype html>
<html <?php language_attributes(); ?>>
<head>
    <meta charset="<?php bloginfo( 'charset' ); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
<?php wp_body_open(); ?>

<div class="tw-shell">
    <header class="tw-header" role="banner">
        <div class="tw-header__inner">
            <div class="tw-brand"><?php echo esc_html( get_bloginfo( 'name' ) ); ?></div>
            <nav>
                <?php if ( is_user_logged_in() ) : ?>
                    <a href="<?php echo esc_url( wp_logout_url( home_url( '/' ) ) ); ?>"><?php echo esc_html__( 'Log out', 'tightship-workspace' ); ?></a>
                <?php endif; ?>
            </nav>
        </div>
    </header>
    <main class="tw-main" role="main">
