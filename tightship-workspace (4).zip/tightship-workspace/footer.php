<?php
declare(strict_types=1);

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

?>
    </main>
    <footer class="tw-footer" role="contentinfo">
        <div class="tw-footer__inner">
            <?php echo esc_html__( 'Powered by WordPress. TightShip-ready.', 'tightship-workspace' ); ?>
        </div>
    </footer>
</div>

<?php wp_footer(); ?>
</body>
</html>
